Conseguimos implementar as funcionalidades pedidas no enunciado e ambos os programas têm o desempenho esperado.
Para testar a correta abertura dos fifos fazemos várias tentativas separadas por chamadas sleep(),
algo que poderemos ter que alterar na próxima entrega.
Ao ser chamado o programa Qn com os argumentos "-l nplaces" ou "-n nthreads", o programa corre normalmente, 
da mesma forma que correria caso não estivessem presentes.
Para compilar o código basta utilizar o comando "make all" na consola. 